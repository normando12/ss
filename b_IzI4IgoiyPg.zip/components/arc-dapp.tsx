"use client"

import { useState, useCallback } from "react"
import { Sparkles, Wallet, Activity, ChevronRight, Globe, ThumbsUp, ThumbsDown, ExternalLink, X, CheckCircle } from "lucide-react"
import { motion } from "framer-motion"
import confetti from "canvas-confetti"

// Twitter/X Icon Component
function TwitterIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  )
}

// Discord Icon Component
function DiscordIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
    </svg>
  )
}

export function ArcDApp() {
  const [isConnecting, setIsConnecting] = useState(false)
  const [isGMLoading, setIsGMLoading] = useState(false)
  const [gmButtonGreen, setGmButtonGreen] = useState(false)
  const [chambers, setChambers] = useState([
    { id: "001", title: "Institutional FX Liquidity Program", status: "Active", votes: 68, time: "12h left", userVote: null as "yes" | "no" | null },
    { id: "002", title: "Adjust Stability Fee", status: "Active", votes: 42, time: "2d left", userVote: null as "yes" | "no" | null },
  ])
  const [showSuccessPopup, setShowSuccessPopup] = useState(false)
  const [transactionData, setTransactionData] = useState<{
    type: "gm" | "vote"
    txHash: string
    voteType?: "yes" | "no"
    proposalTitle?: string
  } | null>(null)

  // Generate random transaction hash
  const generateTxHash = () => {
    return "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("")
  }

  // Share on X
  const shareOnX = () => {
    if (!transactionData) return
    
    let message = ""
    if (transactionData.type === "gm") {
      message = `I just said GM on @arc testnet! Join the decentralized governance revolution. @sonic_fx0`
    } else {
      message = `I just voted ${transactionData.voteType?.toUpperCase()} on "${transactionData.proposalTitle}" on @arc testnet! @sonic_fx0`
    }
    
    const txUrl = `https://testnet.arcscan.app/tx/${transactionData.txHash}`
    const fullMessage = `${message}\n\nTransaction: ${txUrl}`
    
    const tweetUrl = `https://x.com/intent/tweet?text=${encodeURIComponent(fullMessage)}`
    window.open(tweetUrl, "_blank")
  }

  // Play celebration sound
  const playFireworkSound = useCallback(() => {
    const audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    
    const playChime = (time: number, freq: number) => {
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)
      
      oscillator.type = "sine"
      oscillator.frequency.setValueAtTime(freq, audioContext.currentTime + time)
      
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime + time)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + time + 0.4)
      
      oscillator.start(audioContext.currentTime + time)
      oscillator.stop(audioContext.currentTime + time + 0.4)
    }

    // Ascending chime melody over 2 seconds
    const notes = [523, 659, 784, 1047, 784, 1047, 1319, 1568]
    notes.forEach((freq, i) => {
      playChime(i * 0.25, freq)
    })
  }, [])

  // Confetti from both sides
  const fireConfetti = useCallback(() => {
    const duration = 3000
    const animationEnd = Date.now() + duration
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 }

    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min

    const interval = window.setInterval(() => {
      const timeLeft = animationEnd - Date.now()

      if (timeLeft <= 0) {
        return clearInterval(interval)
      }

      const particleCount = 50 * (timeLeft / duration)

      // Left side confetti
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        colors: ["#4D88FF", "#00FF41", "#00E0FF", "#ffffff"],
      })

      // Right side confetti
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        colors: ["#4D88FF", "#00FF41", "#00E0FF", "#ffffff"],
      })
    }, 250)
  }, [])

  const handleGM = () => {
    setIsGMLoading(true)
    setTimeout(() => {
      setIsGMLoading(false)
      setGmButtonGreen(true)
      fireConfetti()
      playFireworkSound()
      
      // Show success popup
      const txHash = generateTxHash()
      setTransactionData({ type: "gm", txHash })
      setShowSuccessPopup(true)
      
      // Return to blue after 2 seconds
      setTimeout(() => setGmButtonGreen(false), 2000)
    }, 1500)
  }

  const handleVote = (chamberId: string, vote: "yes" | "no") => {
    const chamber = chambers.find(c => c.id === chamberId)
    
    setChambers((prev) =>
      prev.map((c) =>
        c.id === chamberId
          ? {
              ...c,
              userVote: vote,
              votes: vote === "yes" ? Math.min(c.votes + 5, 100) : Math.max(c.votes - 3, 0),
            }
          : c
      )
    )
    fireConfetti()
    playFireworkSound()
    
    // Show success popup
    const txHash = generateTxHash()
    setTransactionData({ 
      type: "vote", 
      txHash, 
      voteType: vote,
      proposalTitle: chamber?.title 
    })
    setShowSuccessPopup(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0d1a2d] to-[#0a1628] text-white font-sans selection:bg-arc-blue/30">
      {/* Success Transaction Popup */}
      {showSuccessPopup && transactionData && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm px-4"
          onClick={() => setShowSuccessPopup(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-[#0d1a2d] border border-arc-green/30 rounded-lg p-8 max-w-md w-full shadow-2xl shadow-arc-green/10"
          >
            {/* Close Button */}
            <button
              onClick={() => setShowSuccessPopup(false)}
              className="absolute top-4 right-4 text-white/40 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>

            {/* Success Icon */}
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-arc-green/20 rounded-full flex items-center justify-center">
                <CheckCircle size={40} className="text-arc-green" />
              </div>
            </div>

            {/* Title */}
            <h3 className="text-2xl font-bold text-center mb-2 text-white">
              Transaction Successful!
            </h3>
            <p className="text-center text-white/60 mb-6">
              {transactionData.type === "gm" 
                ? "Your GM presence has been recorded on-chain."
                : `You voted ${transactionData.voteType?.toUpperCase()} on the proposal.`
              }
            </p>

            {/* Transaction Hash */}
            <div className="bg-black/30 rounded-lg p-4 mb-6">
              <p className="text-xs text-white/40 mb-2 font-mono">TRANSACTION HASH</p>
              <p className="text-sm font-mono text-arc-cyan break-all">
                {transactionData.txHash.slice(0, 20)}...{transactionData.txHash.slice(-10)}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-3">
              <a
                href={`https://testnet.arcscan.app/tx/${transactionData.txHash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 px-4 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors text-sm font-medium"
              >
                <ExternalLink size={16} />
                View on Arc Explorer
              </a>
              
              <button
                onClick={shareOnX}
                className="flex items-center justify-center gap-2 py-3 px-4 bg-arc-blue hover:bg-arc-blue/80 text-black rounded-lg transition-colors text-sm font-bold"
              >
                <TwitterIcon className="w-4 h-4" />
                Share on X
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
      {/* TOP FOOTER - Links */}
      <div className="w-full bg-arc-blue/10 border-b border-arc-blue/20 py-2">
        <div className="max-w-7xl mx-auto px-6 flex justify-center items-center gap-6 flex-wrap">
          <a
            href="https://faucet.circle.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs font-mono text-arc-cyan hover:text-white transition-colors"
          >
            <ExternalLink size={12} />
            Faucet USDC
          </a>
          <div className="h-3 w-px bg-white/20" />
          <a
            href="https://www.arc.network/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs font-mono text-arc-blue hover:text-white transition-colors"
          >
            <Globe size={12} />
            Official Website
          </a>
          <div className="h-3 w-px bg-white/20" />
          <a
            href="https://docs.arc.network/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs font-mono text-arc-green hover:text-white transition-colors"
          >
            <ExternalLink size={12} />
            Documentation
          </a>
        </div>
      </div>

      {/* 1. NAVIGATION BAR */}
      <nav className="fixed top-10 w-full z-50 border-b border-white/10 backdrop-blur-xl bg-[#0a1628]/80">
        <div className="max-w-7xl mx-auto px-6 h-16 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%7B9EB52675-2C87-473B-910E-E7B89BDA3FBE%7D-5OhxBa0LvZHcX7wCu1e1t4Dq4mFGBg.png" 
              alt="Arc Logo" 
              className="w-7 h-7 object-contain flex-shrink-0"
            />
            <span className="font-bold tracking-widest text-lg">Arc Core</span>
          </div>

          <div className="flex items-center gap-6">
            {/* Social Icons */}
            <div className="flex items-center gap-3">
              <a
                href="https://x.com/arc"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/40 hover:text-arc-blue transition-colors"
                aria-label="X"
              >
                <TwitterIcon className="w-5 h-5" />
              </a>
              <a
                href="https://discord.com/invite/buildonarc"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/40 hover:text-arc-blue transition-colors"
                aria-label="Discord"
              >
                <DiscordIcon className="w-5 h-5" />
              </a>
            </div>

            <div className="hidden md:flex gap-4 text-xs font-mono text-white/40">
              <span className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 bg-arc-green rounded-full" /> TestNet
              </span>
              <span>GAS: 12 GWEI</span>
            </div>
            <button
              onClick={() => setIsConnecting(!isConnecting)}
              className="px-5 py-2 border border-white/10 rounded-full text-sm font-medium hover:bg-arc-blue hover:text-black hover:border-arc-blue transition-all duration-300 flex items-center gap-2"
            >
              <Wallet size={16} />
              {isConnecting ? "0x71C...4f2" : "Connect Wallet"}
            </button>
          </div>
        </div>
      </nav>

      {/* 2. HERO SECTION */}
      <main className="pt-40 pb-20 max-w-5xl mx-auto px-6">
        <header className="text-center mb-20">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl md:text-8xl font-bold tracking-tighter mb-6 bg-gradient-to-b from-white to-white/30 bg-clip-text text-transparent"
          >
            GOVERNANCE
          </motion.h1>
          <p className="text-arc-gray text-lg font-light tracking-wide max-w-xl mx-auto">
            Interact with the Arc ecosystem through Proof of Presence and decentralized governance.
          </p>
        </header>

        {/* 3. THE GM ACTION BUTTON */}
        <section className="flex flex-col items-center mb-32">
          <div className="relative group">
            {/* Outer Glow Effect */}
            <div
              className={`absolute -inset-1 rounded-full blur-xl transition duration-1000 group-hover:duration-200 animate-pulse ${
                gmButtonGreen ? "bg-arc-green opacity-50" : "bg-arc-blue opacity-20 group-hover:opacity-50"
              }`}
            />

            <motion.button
              onClick={handleGM}
              disabled={isGMLoading}
              animate={{
                backgroundColor: gmButtonGreen ? "#00FF41" : "#4D88FF",
              }}
              transition={{ duration: 0.3 }}
              className="relative px-12 py-5 text-black font-black text-2xl rounded-full flex items-center gap-3 hover:scale-105 active:scale-95 transition-transform disabled:opacity-80"
              style={{ backgroundColor: gmButtonGreen ? "#00FF41" : "#4D88FF" }}
            >
              {isGMLoading ? (
                <div className="w-8 h-8 border-4 border-black/20 border-t-black rounded-full animate-spin" />
              ) : (
                <>
                  SAY GM <Sparkles size={24} />
                </>
              )}
            </motion.button>
          </div>
          <p className="mt-6 font-mono text-[10px] text-white/30 uppercase tracking-[0.2em]">
            Execute Presence Transaction
          </p>
        </section>

        {/* 4. ACTIVE CHAMBERS (GRID) */}
        <section>
          <div className="flex justify-between items-center mb-8 border-b border-white/5 pb-4">
            <h2 className="flex items-center gap-2 font-semibold text-xl tracking-tight">
              <Activity size={20} className="text-arc-blue" />
              ACTIVE CHAMBERS
            </h2>
            <span className="text-arc-gray text-xs font-mono uppercase tracking-widest">Total Proposals: 42</span>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {chambers.map((chamber) => (
              <motion.div
                key={chamber.id}
                whileHover={{ borderColor: "rgba(77, 136, 255, 0.4)" }}
                className="p-8 border border-white/10 bg-[#0d1a2d]/80 rounded-sm transition-colors group"
              >
                <div className="flex justify-between items-start mb-6">
                  <span className="text-[10px] font-mono text-arc-gray tracking-widest uppercase">
                    ID: {chamber.id}
                  </span>
                  <div className="flex items-center gap-2 bg-arc-green/5 px-3 py-1 rounded-full border border-arc-green/20">
                    <div className="w-1.5 h-1.5 bg-arc-green rounded-full animate-pulse shadow-[0_0_8px_#00FF41]" />
                    <span className="text-arc-green text-[10px] font-bold uppercase">{chamber.status}</span>
                  </div>
                </div>

                <h3 className="text-2xl font-medium mb-6 group-hover:text-arc-blue transition-colors line-clamp-1">
                  {chamber.title}
                </h3>

                <div className="space-y-4">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-white/40">VOTING PROGRESS</span>
                    <span>{chamber.votes}%</span>
                  </div>
                  <div className="w-full bg-white/5 h-[2px]">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${chamber.votes}%` }}
                      className="bg-arc-cyan h-full shadow-[0_0_10px_#00E0FF]"
                    />
                  </div>
                  <div className="flex justify-between items-center pt-2">
                    <span className="text-[10px] text-white/30 font-mono italic">{chamber.time} remaining</span>
                    <ChevronRight
                      size={16}
                      className="text-arc-blue opacity-0 group-hover:opacity-100 transition-opacity"
                    />
                  </div>

                  {/* Vote Buttons */}
                  <div className="flex gap-3 pt-4 border-t border-white/5 mt-4">
                    <button
                      onClick={() => handleVote(chamber.id, "yes")}
                      disabled={chamber.userVote !== null}
                      className={`flex-1 py-3 px-4 rounded-sm font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                        chamber.userVote === "yes"
                          ? "bg-arc-green text-black"
                          : chamber.userVote === "no"
                            ? "bg-white/5 text-white/30 cursor-not-allowed"
                            : "bg-arc-green/10 text-arc-green border border-arc-green/30 hover:bg-arc-green hover:text-black"
                      }`}
                    >
                      <ThumbsUp size={16} />
                      YES
                    </button>
                    <button
                      onClick={() => handleVote(chamber.id, "no")}
                      disabled={chamber.userVote !== null}
                      className={`flex-1 py-3 px-4 rounded-sm font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                        chamber.userVote === "no"
                          ? "bg-red-500 text-white"
                          : chamber.userVote === "yes"
                            ? "bg-white/5 text-white/30 cursor-not-allowed"
                            : "bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500 hover:text-white"
                      }`}
                    >
                      <ThumbsDown size={16} />
                      NO
                    </button>
                  </div>
                  {chamber.userVote && (
                    <p className="text-center text-xs text-arc-cyan font-mono mt-2">
                      You voted: {chamber.userVote === "yes" ? "YES" : "NO"}
                    </p>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="py-10 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          {/* Main Footer Message */}
          <div className="text-center mb-8">
            <p className="text-2xl font-bold tracking-wide text-white">
              Building the next layer of global finance.
            </p>
          </div>

          <div className="flex justify-center items-center gap-6 mb-4 flex-wrap">
            <a
              href="https://community.arc.network/home"
              target="_blank"
              rel="noopener noreferrer"
              className="text-arc-blue hover:text-white transition-colors font-medium text-sm"
            >
              Join the Arc community
            </a>
            <div className="h-4 w-px bg-white/20" />
            <a
              href="https://normando12.github.io/arc-corewhitepaper/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-arc-cyan hover:text-white transition-colors font-medium text-sm"
            >
              ARC CORE Whitepaper
            </a>
            <div className="h-4 w-px bg-white/20" />
            <a
              href="https://testnet.arcscan.app/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-arc-green hover:text-white transition-colors font-medium text-sm"
            >
              Arc Testnet Explorer
            </a>
          </div>

          <div className="flex justify-center items-center gap-4">
            <Globe size={14} className="text-white/20" />
            <span className="text-[10px] font-mono text-white/20 tracking-tighter uppercase font-light">
              Arc Core Protocol v1.0.4-Stable
            </span>
          </div>
        </div>
      </footer>
    </div>
  )
}
